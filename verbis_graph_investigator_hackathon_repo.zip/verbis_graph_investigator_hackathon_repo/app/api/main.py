from fastapi import FastAPI
from app.schemas.models import InvestigationRequest
from app.services.orchestrator import run_investigation

app = FastAPI(title="Verbis Graph Investigator", version="0.1.0")


@app.get("/health")
def health() -> dict:
    return {"status": "ok", "service": "verbis-graph-investigator"}


@app.get("/sample-report")
def sample_report() -> dict:
    request = InvestigationRequest(
        workspace_id="demo-startup-dataroom",
        goal="Prepare an investment diligence memo",
        focus_areas=["revenue support", "contract obligations", "missing evidence"],
    )
    return run_investigation(request).model_dump()


@app.post("/investigate")
def investigate(request: InvestigationRequest) -> dict:
    return run_investigation(request).model_dump()
