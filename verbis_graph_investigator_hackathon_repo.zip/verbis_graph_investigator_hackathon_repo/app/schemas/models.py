from typing import List
from pydantic import BaseModel, Field


class InvestigationRequest(BaseModel):
    workspace_id: str = Field(..., description="Workspace or data room identifier")
    goal: str = Field(..., description="Primary diligence goal")
    focus_areas: List[str] = Field(default_factory=list)


class EvidenceItem(BaseModel):
    source_id: str
    title: str
    excerpt: str
    relation: str
    confidence: float


class Finding(BaseModel):
    category: str
    summary: str
    severity: str
    confidence: float
    evidence: List[EvidenceItem] = Field(default_factory=list)


class InvestigationPlan(BaseModel):
    steps: List[str]
    focus_areas: List[str]


class MemoSection(BaseModel):
    heading: str
    body: str


class InvestigationResponse(BaseModel):
    workspace_id: str
    plan: InvestigationPlan
    findings: List[Finding]
    memo: List[MemoSection]
    missing_evidence: List[str]
    unsupported_claims: List[str]
