from app.schemas.models import Finding
from app.services.verbis_graph_client import VerbisGraphClient


def collect_findings(workspace_id: str, focus_areas: list[str]) -> list[Finding]:
    client = VerbisGraphClient()
    findings: list[Finding] = []

    for area in focus_areas:
        evidence = client.retrieve_evidence(workspace_id, area)
        findings.append(
            Finding(
                category=area,
                summary=f"Initial evidence review completed for: {area}",
                severity="medium",
                confidence=0.78,
                evidence=evidence,
            )
        )
    return findings
