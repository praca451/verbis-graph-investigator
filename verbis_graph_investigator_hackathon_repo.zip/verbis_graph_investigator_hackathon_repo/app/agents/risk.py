from app.schemas.models import Finding


def score_findings(findings: list[Finding]) -> list[Finding]:
    for finding in findings:
        if "revenue" in finding.category.lower():
            finding.severity = "high"
            finding.summary = "Revenue-related claims require closer validation against contracts and invoices."
        elif "contract" in finding.category.lower():
            finding.severity = "medium"
            finding.summary = "Contract obligations appear partially grounded but need full clause review."
        elif "missing" in finding.category.lower():
            finding.severity = "high"
            finding.summary = "Evidence gaps materially affect diligence confidence."
        else:
            finding.severity = "medium"
    return findings
