from app.schemas.models import Finding, MemoSection


def draft_memo(findings: list[Finding], missing_evidence: list[str], unsupported_claims: list[str]) -> list[MemoSection]:
    key_risks = "; ".join(f"{f.category}: {f.severity}" for f in findings)
    missing = "; ".join(missing_evidence) if missing_evidence else "No major missing evidence detected."
    unsupported = "; ".join(unsupported_claims) if unsupported_claims else "No unsupported claims flagged."

    return [
        MemoSection(
            heading="Executive Summary",
            body="Verbis Graph Investigator completed an initial graph-based diligence review and identified evidence gaps that should be resolved before investment committee review.",
        ),
        MemoSection(
            heading="Key Risks",
            body=f"Primary findings by category: {key_risks}.",
        ),
        MemoSection(
            heading="Unsupported Claims",
            body=unsupported,
        ),
        MemoSection(
            heading="Missing Evidence",
            body=missing,
        ),
        MemoSection(
            heading="Recommendation",
            body="Proceed with caution and request missing documents before final diligence sign-off.",
        ),
    ]
