from app.schemas.models import InvestigationPlan


def build_plan(goal: str, focus_areas: list[str]) -> InvestigationPlan:
    default_focus = focus_areas or [
        "revenue support",
        "customer evidence",
        "contract obligations",
        "missing proof",
    ]
    steps = [
        f"Interpret diligence objective: {goal}",
        "Query Verbis Graph for relevant entities, claims, obligations, and source passages",
        "Check for supporting and contradictory evidence across documents",
        "Classify findings by risk and confidence",
        "Draft memo with citations and missing evidence checklist",
    ]
    return InvestigationPlan(steps=steps, focus_areas=default_focus)
