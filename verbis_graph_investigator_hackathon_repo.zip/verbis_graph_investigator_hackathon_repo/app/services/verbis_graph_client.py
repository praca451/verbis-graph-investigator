from app.schemas.models import EvidenceItem


class VerbisGraphClient:
    """
    Lightweight mock adapter representing the Verbis Graph layer.

    In a real integration, this client would:
    - query ontology-aware entities and relationships
    - retrieve supporting and contradictory evidence
    - traverse multi-hop graph paths
    - return source-grounded passages with citations
    """

    def __init__(self, endpoint: str | None = None) -> None:
        self.endpoint = endpoint or "mock://verbis-graph"

    def retrieve_evidence(self, workspace_id: str, question: str) -> list[EvidenceItem]:
        samples = [
            EvidenceItem(
                source_id="deck-01",
                title="Pitch Deck Q1 2025",
                excerpt="ARR is stated as €420k with 12 enterprise customers.",
                relation="claim",
                confidence=0.79,
            ),
            EvidenceItem(
                source_id="contract-07",
                title="Customer Contract - Northwind",
                excerpt="Signed annual contract value of €120k effective Jan 2025.",
                relation="supports",
                confidence=0.91,
            ),
            EvidenceItem(
                source_id="invoice-03",
                title="Invoice Batch March 2025",
                excerpt="Recognized invoiced total suggests lower confirmed revenue than deck headline.",
                relation="contradicts",
                confidence=0.74,
            ),
        ]
        return samples

    def list_missing_evidence(self, workspace_id: str) -> list[str]:
        return [
            "Signed contract for one referenced enterprise customer",
            "Latest cap table version",
            "Formal security certification evidence",
        ]
