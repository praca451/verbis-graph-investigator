from app.agents.planner import build_plan
from app.agents.evidence import collect_findings
from app.agents.risk import score_findings
from app.agents.memo import draft_memo
from app.schemas.models import InvestigationRequest, InvestigationResponse
from app.services.verbis_graph_client import VerbisGraphClient


def run_investigation(request: InvestigationRequest) -> InvestigationResponse:
    plan = build_plan(request.goal, request.focus_areas)
    findings = collect_findings(request.workspace_id, plan.focus_areas)
    findings = score_findings(findings)

    client = VerbisGraphClient()
    missing_evidence = client.list_missing_evidence(request.workspace_id)
    unsupported_claims = [
        "Deck ARR headline is not fully supported by signed contracts and invoices in the current workspace."
    ]

    memo = draft_memo(findings, missing_evidence, unsupported_claims)

    return InvestigationResponse(
        workspace_id=request.workspace_id,
        plan=plan,
        findings=findings,
        memo=memo,
        missing_evidence=missing_evidence,
        unsupported_claims=unsupported_claims,
    )
