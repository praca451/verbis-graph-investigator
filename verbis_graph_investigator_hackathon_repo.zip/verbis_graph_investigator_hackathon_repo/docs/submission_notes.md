# Submission Notes

## What exists today
- Verbis Graph as the core knowledge layer
- Graph-based retrieval, ontology structuring, evidence linking, and multi-hop reasoning

## What this hackathon concept adds
- An investor-facing diligence workflow
- Agent orchestration around Verbis Graph
- Structured outputs: memo, unsupported claims, missing evidence, risk summary

## Why this repo exists
This repository is a lightweight review package for judges. It focuses on:
- architecture clarity
- workflow design
- agent boundaries
- explainability of graph-based diligence

## Suggested sentence for the Code field
This repository contains the challenge architecture and code scaffold for Verbis Graph Investigator, built on top of Verbis Graph as the knowledge retrieval, ontology, and multi-hop reasoning layer.
